package lab3act;


public class HabitacionBasica implements ServicioLimpieza { // Clase de categoría básica que solo implementa el servicio de aseo

    private int numero; // Identificador numérico de la habitación

    // Constructor que asigna el número de la habitación al instanciarla
    public HabitacionBasica(int numero) {
        this.numero = numero; // Guarda el número recibido en el atributo correspondiente
    }

    @Override // Sobreescribe el método obligatorio de la interfaz ServicioLimpieza
    public void solicitarLimpieza() {
        System.out.println(
                "Limpieza solicitada para habitación " + numero
        ); // Imprime en consola la confirmación de la orden de aseo para esta habitación
    }
}