package lab3act; 

import java.time.LocalDate; // Importa la clase para manejar fechas sin zona horaria
import java.util.List; // Importa la interfaz List para manejar colecciones ordenadas

public class GestorDisponibilidadHabitacion { // Declaración de la clase que gestiona la disponibilidad

    private List<Reserva> reservas; // Atributo privado que almacena la lista de reservas registradas

    // Constructor que inicializa el gestor con una lista existente de reservas
    public GestorDisponibilidadHabitacion(List<Reserva> reservas) {
        this.reservas = reservas; // Asigna la lista recibida por parámetro al atributo de la clase
    }

    // Método que evalúa si un rango de fechas está libre para reservar
    public boolean estaDisponible(LocalDate inicio, LocalDate fin) {

        for (Reserva reserva : reservas) { // Itera sobre cada reserva almacenada en la lista

            // Condición de solapamiento: el rango solicitado se cruza con una reserva existente
            if (inicio.isBefore(reserva.getFechaFin()) && 
                fin.isAfter(reserva.getFechaInicio())) { 
                return false; // Retorna falso inmediatamente si se detecta un conflicto de fechas
            }
        }
        return true; // Retorna verdadero si se revisaron todas y ninguna fecha se cruzó
    }

    // Metodo para registrar una nueva reserva en el sistema
    public void agregarReserva(Reserva reserva) {
        reservas.add(reserva); // Añade el objeto Reserva al final de la lista
    }
}