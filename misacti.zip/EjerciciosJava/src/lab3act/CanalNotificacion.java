package lab3act;

public interface CanalNotificacion { // Contrato para desacoplar el medio de envío de notificaciones 

    void enviarNotificacion(String mensaje); // Define el método abstracto para enviar un mensaje al cliente
}