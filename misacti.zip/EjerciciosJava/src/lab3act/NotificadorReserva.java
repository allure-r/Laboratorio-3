package lab3act;

public class NotificadorReserva { // Clase encargada de emitir alertas de reservas

    private CanalNotificacion canal; // Atributo desacoplado que apunta a la abstracción (interfaz)

    // Constructor que aplica Inyección de Dependencias recibiendo cualquier implementación de CanalNotificacion
    public NotificadorReserva(CanalNotificacion canal) {
        this.canal = canal; // Asigna el canal concreto suministrado al atributo de la clase
    }

    // Método público para emitir un aviso al huésped
    public void notificar(String mensaje) {

        canal.enviarNotificacion(mensaje); // Delega el envío al canal inyectado sin acoplarse a una tecnología específica
    }
}