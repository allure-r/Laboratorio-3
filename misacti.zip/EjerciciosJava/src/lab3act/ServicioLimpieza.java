package lab3act;


public interface ServicioLimpieza { // Interfaz que define el contrato para habitaciones que admiten servicio de aseo

    void solicitarLimpieza(); // Firma del método para despachar o registrar la solicitud de limpieza de la habitación
}