package lab3act;

public interface ServicioLavanderia { // Interfaz que define el contrato para habitaciones con soporte de lavandería

    void solicitarLavanderia(); // Firma del método para despachar o registrar la solicitud de servicio de lavandería
}