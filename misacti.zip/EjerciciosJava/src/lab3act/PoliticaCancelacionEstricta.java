package lab3act;

public class PoliticaCancelacionEstricta implements PoliticaCancelacion { // Implementa la regla de no reembolsos

    @Override // Indica que sobreescribe la operación exigida por la interfaz
    public boolean puedeCancelar(Reserva reserva) { // Evalúa las condiciones para aceptar la anulación

        return false; // Deniega siempre la anulación sin importar la fecha ni el plazo
    }
}