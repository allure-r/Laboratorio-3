package lab3act;

public class ControladorServicios { // Controlador encargado de despachar los servicios según las interfaces implementadas

    // Recibe un objeto genérico para verificar dinámicamente qué servicios soporta
    public void gestionarServicios(Object habitacion) {

        if (habitacion instanceof ServicioLimpieza) { // Comprueba si el objeto implementa el contrato de limpieza
            ServicioLimpieza limpieza =
                    (ServicioLimpieza) habitacion; // Aplica un casteo explícito a la interfaz ServicioLimpieza
            limpieza.solicitarLimpieza(); // Ejecuta la acción correspondiente al aseo de la habitación
        }

        if (habitacion instanceof ServicioComida) { // Comprueba si el objeto implementa el contrato de comida
            ServicioComida comida =
                    (ServicioComida) habitacion; // Aplica un casteo explícito a la interfaz ServicioComida
            comida.solicitarComida(); // Ejecuta la orden de alimentos a la habitación
        }

        if (habitacion instanceof ServicioLavanderia) { // Comprueba si el objeto implementa el contrato de lavandería
            ServicioLavanderia lavanderia =
                    (ServicioLavanderia) habitacion; // Aplica un casteo explícito a la interfaz ServicioLavanderia
            lavanderia.solicitarLavanderia(); // Ejecuta la orden de lavado de prendas
        }
    }
}