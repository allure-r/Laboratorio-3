package lab3act;

public interface PoliticaCancelacion { // Contrato para definir distintas reglas de anulación de reservas

    boolean puedeCancelar(Reserva reserva); // Evalua si una reserva cumple las condiciones para ser cancelada
}
