package lab3act;

//Implementa múltiples interfaces de servicios 
public class HabitacionPremium implements ServicioLimpieza,  ServicioComida,  ServicioLavanderia { 

    private int numero; // Identificador numérico único de la habitación premium

    // Constructor que inicializa el número de la habitación
    public HabitacionPremium(int numero) {
        this.numero = numero; // Asigna el identificador recibido al atributo de la clase
    }
    @Override // Sobreescribe el método proveniente de la interfaz ServicioLimpieza
    public void solicitarLimpieza() {
        System.out.println( "Limpieza solicitada para habitación " + numero);// Emite por consola la confirmación del servicio de aseo
    }
    @Override // Sobreescribe el método proveniente de la interfaz ServicioComida
    public void solicitarComida() {
        System.out.println("Comida solicitada para habitación " + numero );
        // Emite por consola la solicitud de room service para alimentación
    }
    @Override // Sobreescribe el método proveniente de la interfaz ServicioLavanderia
    public void solicitarLavanderia() {
        System.out.println(
                "Lavandería solicitada para habitación " + numero
        ); // Emite por consola la solicitud de servicio de lavado de prendas
    }
}