package lab3act;

public class EnviadorSMS implements CanalNotificacion { // Implementación concreta del canal a través de mensajes de texto

    @Override // Sobreescribe el método de la interfaz CanalNotificacion
    public void enviarNotificacion(String mensaje) {

        System.out.println(  "Enviando SMS: " + mensaje  ); // Imprime en consola simulando la transmisión de un mensaje SMS
    }
}