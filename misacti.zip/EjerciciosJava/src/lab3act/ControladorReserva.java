package lab3act;

public class ControladorReserva { // Controlador que gestiona los canales de alerta hacia los huéspedes

    // Despacha un mensaje configurando el canal de correo electrónico
    public void enviarNotificacionCorreo(String mensaje) {

        CanalNotificacion correo =
                new EnviadorCorreo(); // Instancia la implementación concreta basada en correo

        NotificadorReserva notificador =
                new NotificadorReserva(correo); // Inyecta el canal de correo en el notificador

        notificador.notificar(mensaje); // Dispara la notificación delegando en la abstracción
    }

    // Despacha un mensaje configurando el canal de mensajería de texto
    public void enviarNotificacionSMS(String mensaje) {

        CanalNotificacion sms =
                new EnviadorSMS(); // Instancia la implementación concreta basada en SMS

        NotificadorReserva notificador =
                new NotificadorReserva(sms); // Inyecta el canal SMS en el notificador

        notificador.notificar(mensaje); // Dispara la notificación delegando en la abstracción
    }
}