package lab3act;

public class EnviadorCorreo implements CanalNotificacion { // Implementación concreta del canal usando correo electrónico

    @Override // Sobreescribe el método definido en el contrato CanalNotificacion
    public void enviarNotificacion(String mensaje) {

        System.out.println(  "Enviando correo: " + mensaje ); // Imprime en consola simulando la transmisión de un correo electrónico
    }
}