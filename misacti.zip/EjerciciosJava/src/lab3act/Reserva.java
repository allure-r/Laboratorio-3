package lab3act;
 
import java.time.LocalDateTime; 

public class Reserva { 

    private String cliente; // Nombre o identificador del titular de la reserva
    private LocalDateTime fechaCheckIn; // Fecha y hora programada para el ingreso del huésped
    private double precio; // Costo total pactado para esta reserva
    private PoliticaCancelacion politicaCancelacion; // Estrategia asignada para determinar si procede una cancelación

    // Constructor para inicializar una reserva con todos sus datos y su política correspondiente
    public Reserva(String cliente,
                   LocalDateTime fechaCheckIn,
                   double precio,
                   PoliticaCancelacion politicaCancelacion) {

        this.cliente = cliente; // Asigna el nombre del cliente
        this.fechaCheckIn = fechaCheckIn; // Asigna el momento programado para el check-in
        this.precio = precio; // Asigna el importe total
        this.politicaCancelacion = politicaCancelacion; // Inyecta la política de cancelación aplicable
    }

    // Intenta anular la reserva evaluando la regla de negocio definida en la política
    public boolean cancelar() {

        // Delega en la política de cancelación la comprobación pasando esta misma instancia (this)
        if (politicaCancelacion.puedeCancelar(this)) { 

            System.out.println("Reserva cancelada correctamente."); // Notifica que la cancelación fue admitida

            return true; // Retorna true confirmando que la anulación procedió con éxito
        }

        System.out.println("No se puede cancelar la reserva."); // Informa que no cumple las condiciones de anulación

        return false; // Retorna false impidiendo la anulación de la reserva
    }

    // Retorna el nombre del cliente titular
    public String getCliente() {
        return cliente; // Devuelve el valor almacenado en el atributo cliente
    }

    // Retorna la fecha y hora fijada para el check-in
    public LocalDateTime getFechaCheckIn() {
        return fechaCheckIn; // Devuelve la instancia LocalDateTime de llegada
    }

    // Retorna el precio asignado a la reserva
    public double getPrecio() {
        return precio; // Devuelve el importe monetario
    }
}