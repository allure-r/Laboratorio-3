package lab3act;


public class Habitacion { // Clase base o padre que modela los atributos comunes de una habitación

    protected int numero; // Identificador numérico de la habitación (accesible por subclases)
    protected double precio; // Tarifa base por noche (accesible por subclases)

    // Constructor que inicializa los atributos esenciales de la habitación
    public Habitacion(int numero, double precio) {
        this.numero = numero; // Asigna el número recibido por parámetro al atributo de la clase
        this.precio = precio; // Asigna el precio por noche recibido por parámetro
    }

    // Calcula el costo total multiplicando la tarifa base por la cantidad de noches reservadas
    public double calcularPrecio(int noches) {
        return precio * noches; // Retorna el importe total del hospedaje
    }

    // Imprime en consola los detalles generales de la habitación
    public void mostrarInformacion() {
        System.out.println("Habitación número: " + numero); // Imprime el número identificador
        System.out.println("Precio por noche: S/ " + precio); // Imprime la tarifa por noche formateada
    }
}