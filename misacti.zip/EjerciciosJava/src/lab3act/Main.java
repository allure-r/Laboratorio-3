package lab3act;

public class Main { // Clase principal que contiene el punto de entrada de la aplicación

    public static void main(String[] args) { // Método principal de arranque para probar el flujo de notificaciones

        ControladorReserva controlador =
                new ControladorReserva(); // Instancia el controlador encargado de coordinar los envíos

        controlador.enviarNotificacionCorreo(
                "Su reserva fue confirmada."
        ); // Dispara el flujo para notificar al cliente mediante correo electrónico

        controlador.enviarNotificacionSMS(
                "Su reserva fue confirmada."
        ); // Dispara el flujo para notificar al cliente mediante mensaje de texto (SMS)
    }
}