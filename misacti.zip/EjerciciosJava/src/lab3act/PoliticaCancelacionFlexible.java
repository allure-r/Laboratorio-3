package lab3act;


import java.time.Duration; // Importa la clase para medir lapsos de tiempo 
import java.time.LocalDateTime; // Importa la clase para obtener fecha y hora actual

public class PoliticaCancelacionFlexible implements PoliticaCancelacion { // Implementa la regla de cancelación flexible

    @Override // Indica que sobreescribe el método definido en la interfaz PoliticaCancelacion
    public boolean puedeCancelar(Reserva reserva) { // Evalúa si la reserva puede cancelarse bajo esta política

        // Calcula el intervalo temporal exacto entre el instante actual y el check-in programado
        Duration tiempo =
                Duration.between(LocalDateTime.now(), reserva.getFechaCheckIn());

        long horas = tiempo.toHours(); // Extrae y convierte la diferencia temporal a horas totales completas

        return horas >= 24; // Retorna true si faltan 24 horas o más; false si el plazo venció o es negativo
    }
}