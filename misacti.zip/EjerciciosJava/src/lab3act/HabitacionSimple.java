package lab3act;

public class HabitacionSimple extends Habitacion { // Subclase que hereda las propiedades de Habitacion

    // Constructor que inicializa una habitación simple reutilizando la lógica del padre
    public HabitacionSimple(int numero, double precio) {
        super(numero, precio); // Invoca al constructor de la superclase Habitacion con los datos recibidos
    }

    @Override // Indica la sobreescritura del método calcularPrecio definido en la clase padre
    public double calcularPrecio(int noches) {
        return super.calcularPrecio(noches); // Reutiliza el cálculo base (precio * noches) sin recargos adicionales
    }
}