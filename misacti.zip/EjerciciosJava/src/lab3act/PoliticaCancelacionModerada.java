package lab3act;


import java.time.Duration; 
import java.time.LocalDateTime; 

public class PoliticaCancelacionModerada implements PoliticaCancelacion { // Implementa la regla intermedia de cancelación

    @Override // Indica que implementa el método contractual de PoliticaCancelacion
    public boolean puedeCancelar(Reserva reserva) { // Determina si la reserva aplica para anulación moderada

        // Mide la duración transcurrida entre el momento presente y la fecha/hora de entrada
        Duration tiempo =
                Duration.between(LocalDateTime.now(), reserva.getFechaCheckIn());

        long horas = tiempo.toHours(); // Convierte la duración restante a horas completas

        if (horas >= 72) { // Comprueba si aún restan como mínimo 72 horas (3 días) de anticipación

            double penalizacion = reserva.getPrecio() * 0.50; // Aplica un cobro del 50% del total de la reserva como penalidad

            System.out.println("Penalización: S/ " + penalizacion); // Informa en consola el importe retenido por penalización

            return true; // Habilita la cancelación al cumplirse la ventana de tiempo requerida
        }

        return false; // Rechaza la cancelación por realizarse con menos de 72 horas de anticipación
    }
}