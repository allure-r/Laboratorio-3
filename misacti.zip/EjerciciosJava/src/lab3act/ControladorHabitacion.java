package lab3act;


import java.util.List; // Importa la interfaz List para manipular colecciones de habitaciones

public class ControladorHabitacion { // Controlador encargado de la visualización y operaciones sobre habitaciones

    // Método que procesa y muestra por consola los datos de una lista de habitaciones
    public void mostrarHabitaciones(List<Habitacion> habitaciones) {

        for (Habitacion habitacion : habitaciones) { // Itera polimórficamente sobre cada instancia de Habitacion

            habitacion.mostrarInformacion(); // Invoca el método para imprimir los detalles de la habitación

            double total =
                    habitacion.calcularPrecio(3); // Aplica polimorfismo dinámico: ejecuta el cálculo según la subclase

            System.out.println("Precio por 3 noches: S/ " + total); // Imprime el costo calculado para una estancia de 3 noches

            System.out.println("-------------------------"); // Imprime una línea divisoria para separar visualmente los registros
        }
    }
}