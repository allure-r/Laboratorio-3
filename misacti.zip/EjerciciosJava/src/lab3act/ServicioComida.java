package lab3act;

public interface ServicioComida { // Interfaz que define el contrato para habitaciones con servicio de alimentación

    void solicitarComida(); // Firma del método para pedir o despachar servicio a la habitación 
}